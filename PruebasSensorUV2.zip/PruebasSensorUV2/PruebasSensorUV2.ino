#include <WiFi.h>
#include <WiFiUdp.h>
#include <SPIFFS.h>

const char* ssid = "WF1_28572164";
const char* password = "135792468";

WiFiUDP udp;
IPAddress broadcastIP(192, 168, 4, 255);
const int displayPort = 6101;
const int localPort = 59034;

std::vector<String> messages;

// --------------------------------------------------
// Convierte HEX a bytes y envía por UDP
// --------------------------------------------------
void sendHexMessage(const String& hex) {
  if (hex.length() % 2 != 0) {
    Serial.println("⚠ HEX inválido (longitud impar), se omite");
    return;
  }

  int len = hex.length() / 2;
  uint8_t buffer[len];

  for (int i = 0; i < len; i++) {
    buffer[i] = strtol(hex.substring(i * 2, i * 2 + 2).c_str(), nullptr, 16);
  }

  udp.beginPacket(broadcastIP, displayPort);
  udp.write(buffer, len);
  udp.endPacket();

  Serial.println("Enviado:");
  Serial.println(hex);
  Serial.println("---------------------------");
}

// --------------------------------------------------
// Carga mensajes desde SPIFFS
// --------------------------------------------------
void loadMessages() {
  messages.clear();

  File f = SPIFFS.open("/compendio_msgs2.txt", "r");
  if (!f) {
    Serial.println("❌ No se pudo abrir compendio_msgs.txt");
    return;
  }

  while (f.available()) {
    String line = f.readStringUntil('\n');
    line.trim();

    if (line.length() == 0) continue;
    if (line.startsWith("//")) continue;

    int q1 = line.indexOf('"');
    int q2 = line.indexOf('"', q1 + 1);

    if (q1 >= 0 && q2 > q1) {
      messages.push_back(line.substring(q1 + 1, q2));
    }
  }

  f.close();
  Serial.printf("✔ Mensajes cargados: %d\n", messages.size());
}

// --------------------------------------------------



int UVOUT = 34; //Output from the sensor
int REF_3V3 = 35; //3.3V power on the ESP32 board
int tiempo = 0;
int prevuvIndex = 0;
bool bandera = 0;
int cuenta = 0;
void setup()
{
  // initialize the LCD
  Serial.begin(115200);  
  pinMode(UVOUT, INPUT);
  pinMode(REF_3V3, INPUT);
  if (!SPIFFS.begin(true)) {
    Serial.println("❌ Error montando SPIFFS");
    return;
  }

  loadMessages();

  WiFi.begin(ssid, password);
  Serial.print("Conectando WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  
  }
  Serial.println("\n✔ WiFi conectado");

  udp.begin(localPort);

  Serial.println("\nIngrese el número de grupo (0,1,2,...):");
}

//Takes an average of readings on a given pin
//Returns the average
int averageAnalogRead(int pinToRead)
{
  byte numberOfReadings = 8;
  unsigned int runningValue = 0; 

  for(int x = 0 ; x < numberOfReadings ; x++)
    runningValue += analogRead(pinToRead);
  runningValue /= numberOfReadings;

  return(runningValue);
}

float mapfloat(float x, float in_min, float in_max, float out_min, float out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void loop()
{
  int uvLevel = averageAnalogRead(UVOUT);
  int refLevel = averageAnalogRead(REF_3V3);
  
  //Use the 3.3V power pin as a reference to get a very accurate output value from sensor
  float outputVoltage = 3.3 / refLevel * uvLevel;
  
  float uvIntensity = (outputVoltage - 0.78)*(6.8182*2)*1.6; //mapfloat(outputVoltage, 0.79, 3.0, 0.0, 15.0); //Convert the voltage to a UV intensity level
  //float indexflt = mapfloat(outputVoltage, 0.0, 15.0, 0.0, 12.0);
  int uvIndex = int(uvIntensity);
  

  Serial.print("output: ");
  Serial.print(refLevel);

  Serial.print("ML8511 output: ");
  Serial.print(uvLevel);

  Serial.print(" / ML8511 voltage: ");
  Serial.print(outputVoltage);

  Serial.print(" / UV Intensity (mW/cm^2): ");
  Serial.print(uvIntensity);
  Serial.print(" / UV Index: ");
  Serial.print(uvIndex);
  Serial.println();

  if(uvIndex >= prevuvIndex || uvIndex <= prevuvIndex){
  cuenta++;
  }
  if(cuenta >= 120){
    prevuvIndex = uvIndex;
    bandera = 1;  
  }
  delay(200);


  // Leer línea completa
  

  if(tiempo < 100 && bandera ==1){
    tiempo++;
    Serial.println(tiempo);
  }
  if(tiempo == 100 && bandera == 1){
    tiempo = 0;
    bandera = 0;
    delay(400);

  /*  String input = Serial.readStringUntil('\n');
  input.trim();

  if (input.length() == 0) return;*/

  int grupo = prevuvIndex;

  if (grupo > 12) {
    grupo = 12;
  }
  if (grupo < 0){
    grupo = 0;
  }

  int total = messages.size();
  int start = grupo * 7;
  int end = start + 7;

  if (grupo < 0 || start >= total) {
    Serial.println("❌ Grupo fuera de rango");
    Serial.print(grupo);
    Serial.print("//");
    Serial.print(start);
    Serial.print("//");
    Serial.print(total);
    Serial.print("//");
    return;
  }

  if (end > total) end = total;

  Serial.printf("\n▶ Enviando grupo %d (mensajes %d a %d)\n",
                grupo, start, end - 1);

  for (int i = start; i < end; i++) {
    sendHexMessage(messages[i]);
    delay(100);
  }

  Serial.println("✔ Grupo enviado");
  Serial.println("\nIngrese el siguiente número de grupo:");


  }

}
