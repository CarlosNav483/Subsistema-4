#include <SPIFFS.h>
void setup() {
  // put your setup code here, to run once:
  SPIFFS.format();
}

void loop() {
  // put your main code here, to run repeatedly:

}
